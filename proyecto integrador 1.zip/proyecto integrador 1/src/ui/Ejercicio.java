import java.util.Scanner;
public class Ejercicio{
    public static double promedio(int v1, int v2, int v3, int v4, int v5){
        double resultado= 0;
        resultado= (v1+v2+v3+v4+v5)/5.0;
        
        return resultado;
    }
    public static int division(int v1, int v2, int v3, int v4, int v5){
       return  (v1 % 10 == 0 ? 1 : 0)+
               (v2 % 10 == 0 ? 1 : 0)+
               (v3 % 10 == 0 ? 1 : 0)+
               (v4 % 10 == 0 ? 1 : 0)+
               (v5 % 10 == 0 ? 1 : 0);
    }
    public static boolean division_5(int v1, int v2, int v3, int v4, int v5){
        return (v1 % 5 == 0)||
               (v2 % 5 == 0)||
               (v3 % 5 == 0)||
               (v4 % 5 == 0)||
               (v5 % 5 == 0);



    }
    
        
        
    

public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("ingrese el valor uno:");
        int valor_1= sc.nextInt();
        System.out.println("ingrese el valor dos:");
        int valor_2= sc.nextInt();
        System.out.println("ingrese el valor tres:");
        int valor_3= sc.nextInt();
        System.out.println("ingrese el valor cuatro:");
        int valor_4= sc.nextInt();
        System.out.println("ingrese el valor cinco:");
        int valor_5= sc.nextInt();
        double promedio= promedio(valor_1, valor_2, valor_3, valor_4, valor_5);
        System.out.println("el promedio es:" + promedio);
        int division= division(valor_1, valor_2, valor_3, valor_4, valor_5);
        System.out.println("los numeros divisibles por 10 son:" + division);
        boolean divisible_5= division_5( valor_1, valor_2, valor_3, valor_4, valor_5);
        System.out.println("existe algun numero divisible entre 5:" + (divisible_5 ? "si" : "no"));
        int max = (valor_1 > valor_2 ? valor_1 : valor_2);
        max= (max > valor_3 ? max : valor_3);
        max= (max > valor_4 ? max : valor_4);
        max= (max > valor_5 ? max : valor_5);
        System.out.println("el valor maximo ingresado es: "+ max);




    }



    
}

