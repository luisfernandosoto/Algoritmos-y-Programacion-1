
import java.util.Scanner;

public class Intereses {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("ingrese el interes simple mensual: (1/20)");
        int Interes_Mensual = scanner.nextInt();
        System.out.println("ingrese el valor el prestamo:");
        int Valor_Prestamo = scanner.nextInt();
        System.out.println("ingrese el dia del año: (1/360)");
        int Dia_Año = scanner.nextInt();
        if (Interes_Mensual < 1 || Interes_Mensual > 20) {
            System.out.println("el interes mensual debe estar entre 1 y 20");
            if (Dia_Año < 1 || Dia_Año > 360) {
                System.out.println("el dia del año debe de estar entre 1 y 360");
            }
        }
        int Dias_Restantes = 360 - Dia_Año;
        int Meses_Restantes = Dias_Restantes / 30;
        int Interes_Anual = Interes_Mensual * Meses_Restantes;
        int Valor_Interes = (Valor_Prestamo * Interes_Anual) / 100;
        System.out.println("El interés anual es: " + Interes_Anual);
        System.out.println("El valor del interés a pagar es: " + Valor_Interes);
        scanner.close();
    }
}
