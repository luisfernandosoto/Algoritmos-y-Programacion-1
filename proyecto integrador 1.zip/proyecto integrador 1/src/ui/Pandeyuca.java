public class Pandeyuca{
    public static void main(String[]args){
        int montoMama= 10000;
        int montoCobro= 1700;
        int montoPan= montoMama - montoCobro;
        int montoUnidad_Pan= 1200;
        int cantidad_Pan= montoPan / montoUnidad_Pan;
        System.out.println("la cantidad de pandeyucas es:"+ cantidad_Pan);
        int devuelta= montoPan-(cantidad_Pan * montoUnidad_Pan);
        System.out.println("la devuelta respectiva es:"+ devuelta);
        System.out.println("Fin");
    }
}