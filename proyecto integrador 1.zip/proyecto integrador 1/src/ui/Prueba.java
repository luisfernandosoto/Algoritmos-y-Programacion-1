
import java.util.Scanner;

public class Prueba {

    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("ingrese el primer numero:");
        int primer_numero= sc.nextInt();
        System.out.println("ingrese el segundo numero:");
        int segundo_numero= sc.nextInt();
        int suma_cuadrado= sumaCuad(primer_numero, segundo_numero);
        System.out.println("el resultado es:"+ suma_cuadrado);

        sumaCuadPro(primer_numero, segundo_numero);


    }
    public static int sumaCuad(int v1, int v2){
        int resultado= 0;
        resultado=(v1*v1)+(v2*v2);
        System.out.println("el valor uno es:" + v1);
        System.out.println("el valor dos es:" + v2);
        return resultado;
     }

     public static void sumaCuadPro(int v1, int v2){
        int resultado= 0;
        resultado=(v1*v1)+(v2*v2);
        System.out.println("el valor uno es:" + v1);
        System.out.println("el valor dos es:" + v2);
        System.out.println("la suma de los cuadrados es:" + resultado);
     }
}
   

