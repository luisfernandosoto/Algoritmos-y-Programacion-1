
import java.util.Scanner;
public class Seguimiento{
    /**
     * @param pTemperatura temperatura del dia de hoy ingresada por el usuario. pTemperatura != null && pTemperatura !="".
     * @param pNombre el organizador debe ingresar su nombre. pNombre != null && pNombre != "".
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("ingrese la temperatura:");
        int temperatura= scanner.nextInt();
        System.out.println(verificarTemperatura(temperatura));
        System.out.println("ingrese su nombre:");
        scanner.nextLine();
        String nombre_organizador= scanner.nextLine();
        obtenerRegalo(nombre_organizador);
        scanner.close();
        

      
    }
    public static String verificarTemperatura(int temperatura){
        String mensaje= "Disfrute de la caminata";
        if(temperatura < 15){
            mensaje= "lleve chaqueta para protegerse del frio y de la lluvia";
            
        }else if(temperatura > 28){
            mensaje= "lleve el termo del agua, beba para hidratarse ";
        }
        return mensaje;
    }
    /**
     * @param pValidacion se validara si el nombre del organizador empieza por una vocal o no, la forma de validacion es un mensaje para regalar una entrada gratuita a una conferencia de la COP16. pValidacion != null && pValidacion != "".
     * @param nombre_organizador
     */
    public static void obtenerRegalo(String nombre_organizador){
        char primera_letra= Character.toLowerCase(nombre_organizador.charAt(0));
        if (primera_letra == 'a' || primera_letra == 'e' || primera_letra == 'i' || primera_letra == 'o' || primera_letra == 'u'){
            System.out.println("Comuniquese al numero 1800456789 para obtener una entrada gratuita a una conferencia del COP16.");

        } else{
            System.out.println("muchas gracias");
        }
        
    }
    
}

