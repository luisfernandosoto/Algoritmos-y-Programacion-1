import java.util.Scanner;

public class Valor {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("ingrese el valor de compra:");
        double valor_compra= scanner.nextDouble();
        double Descuento= calcularDescuento(valor_compra);
        double total_pagar= valor_compra-Descuento;
        System.out.println("el valor a pagar es: "+ total_pagar);
        scanner.close();

    }
    public static double calcularDescuento(double c){
        double resultado= 0;
        if(c > 100000){
            resultado= c * 0.25;
        }
    
    return resultado;

    
}
}
