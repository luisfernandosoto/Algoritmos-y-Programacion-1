import java.util.Scanner;

public class cadena {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Ingrese una cadena de 5 caracteres: ");
        String cadena = scanner.nextLine();

       
        if (cadena.length() != 5) {
            System.out.println("La cadena debe tener exactamente 5 caracteres.");
        } else {
            
            String cadenaInvertida = new StringBuilder(cadena).reverse().toString();

            
            System.out.println("La cadena invertida es: " + cadenaInvertida);
        }

        
        scanner.close();
    }
}