import java.util.Scanner;
public class conversion {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("ingrese la cantidad de millas:");
        double millas= scanner.nextDouble();
        double kilometros= millas * 1.60934;
        System.out.println(millas + " millas son " + kilometros + " kilometros.");
        scanner.close();

    }
}
