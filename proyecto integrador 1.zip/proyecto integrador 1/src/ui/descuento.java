import java.util.Scanner;
public class descuento {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("cual es el precio original del celular:");
        double Original= scanner.nextDouble();
        System.out.println("cual es el porcentaje de descuento:");
        double Porcentaje= scanner.nextDouble();
        double Descuento=(Original * Porcentaje)/100;
        double Final= Original - Descuento;
        System.out.println("el precio con el descuento incluido es:"+ Final);
        scanner.close();
        




    }
}
