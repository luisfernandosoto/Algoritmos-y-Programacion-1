import java.util.Scanner;
public class maestro {
    public static void main(String[]args){
        Scanner scanner= new Scanner(System.in);
        System.out.println("cuantos hombres tiene en su curso:");
        int Hombres= scanner.nextInt();
        System.out.println("cuantas mujeres tiene en su curso:");
        int Mujeres= scanner.nextInt();
        int Total= Hombres + Mujeres;
        double porcentajeHombres= ((double) Hombres / Total)*100;
        double porcentajeMujeres= ((double) Mujeres / Total)*100;
        System.out.print("el porcentaje de hombres es:"+ porcentajeHombres + "%");
        System.out.print("el porcentaje de mujeres es:"+ porcentajeMujeres + "%");
        scanner.close();





    }
}
