public class numeros {
    public static void main(String[]args){
        int Segundos_totales= 130;
        int Minutos= Segundos_totales / 60;
        int Segundos_restantes= Segundos_totales % 60;
        System.out.println(Segundos_totales + " segundos son " + Minutos + " minutos y " + Segundos_restantes + " segundos. ");
    }
}
