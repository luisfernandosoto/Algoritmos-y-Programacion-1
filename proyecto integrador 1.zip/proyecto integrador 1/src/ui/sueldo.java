
import java.util.Scanner;
public class sueldo {
    public static void main(String[]args){
        Scanner scanner= new Scanner(System.in);
        System.out.println("ingrese su sueldo actual:");
        double Sueldo= scanner.nextDouble();
        double Aumento= Sueldo*0.05;
        double Nuevo_sueldo= Sueldo + Aumento;
        System.out.println("su nuevo sueldo con el aumento del 5% es de:"+ Nuevo_sueldo);
        scanner.close();

    }
    
}
