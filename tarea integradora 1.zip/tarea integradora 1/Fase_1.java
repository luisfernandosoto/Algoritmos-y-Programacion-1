import java.util.Scanner;

public class Fase_1 {
    /**
     * @param pName         nombre del participante. pName != null && pName != "".
     * @param pId           cedula del participante. pId != null && pId !="".
     * @param pParticipants este es el numero de personas que acudiran a la
     *                      caminata. pParticipants != null && pParticipants != "".
     * @param pGuides       este es el numero de guias que acudiran a la caminata.
     *                      pGuides != null && pGuides != "".
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ingrese su nombre:");
        String name = scanner.nextLine();
        System.out.println("digite su cedula:");
        String cedula = scanner.nextLine();
        System.out.println("bienvenido " + name + ", su cedula es: " + cedula);
        String ruta_seleccionada = obtenerRutaSeleccionada(scanner);
        mostrarInformacionRuta(ruta_seleccionada);
        System.out.println("cuantos participantes acudiran a la caminata:");
        int numero_participantes = scanner.nextInt();
        System.out.println("cuantos guias acudiran a la caminata:");
        int guias = scanner.nextInt();
        double temperatura = obtenerTemperaturayhumedad(scanner, "digite la temperatura:");
        double humedad = obtenerTemperaturayhumedad(scanner, "digite la humedad:");
        System.out
                .println("la temperatura ingresada es: " + temperatura + "y la humedad ingresada es: " + humedad + "%");
        verificacionClima(temperatura, humedad);
        int total_participantes = numero_participantes + guias;
        System.out.println("el total de personas que acudiran a la caminata son: " + total_participantes);
        int numero_buses = mostrarNumeroBuses(total_participantes);
        mostrarNumeroBuses(numero_participantes + guias);
        System.out.println("el numero de buses es: " + numero_buses);
        ejecutarSeguimiento(scanner);
        scanner.close();

    }
    // este bloque de codigo tecnicamente lo que elabora es crear la funcion de
    // obtener ruta seleccionada ya que debe tener como salida un string, y esta
    // debe ser llamada en el main, por que ahi deben estar todas las entradas y las
    // salidas

    public static String obtenerRutaSeleccionada(Scanner scanner) {
        System.out.println("r1. ruta ladera");
        System.out.println("r2. ruta farallones");
        System.out.println("r1. ruta oriente");
        System.out.println("seleccione la ruta que desea abarcar:");
        return scanner.nextLine();

    }
    /**
     *@param pInformacion aqui se mostrara la informacion de la ruta que segun el seleccione. pInformacion != null && pInformacion !="".
     */
    public static void mostrarInformacionRuta(String ruta) {

        if (ruta.equalsIgnoreCase("ruta ladera")) {
            System.out.println("usted ha seleccionado la ruta ladera");
            System.out.println(
                    "¡Excelente! la ruta ladera tiene como punto de encuentro el bulevar del rio, iniciando a las 7:00 am y terminando a las 1:30 pm");

        } else if (ruta.equalsIgnoreCase("ruta farallones")) {
            System.out.println("usted ha seleccionado la ruta farallones");
            System.out.println(
                    "¡Excelente! la ruta farallones tiene como punto de encuentro calle 16 - Universidad del Valle , iniciando a las 6:40 am y terminando a las 4:00 pm");
        } else if (ruta.equalsIgnoreCase("ruta oriente")) {
            System.out.println("usted ha seleccionado la oriente");
            System.out.println(
                    "¡Excelente! la ruta oriente tiene como punto de encuentro el bulevar del rio, iniciando a las 7:00 am y terminando a las 1:00 pm");

        } else {
            System.out.println("usted ha digitado una opcion incorrecta");

        }
    }

    public static double obtenerTemperaturayhumedad(Scanner scanner, String m) {
        System.out.println(m);
        return scanner.nextDouble();

    }
    /**
     * @param pTemperatura aqui se comprobara la condicion de la temperatura. pTemperatura != null && pTemperatura != "".
     * @param pHumedad aqui se comprobara la condicion de la humedad. pHumedad != null && pHumedad != "".
     */

    public static void verificacionClima(double temperatura, double humedad) {
        if ((temperatura > 20 && temperatura < 25) && (humedad > 40 && humedad < 60)) {
            System.out.println("¡hace un buen dia para caminar por cali!");
        } else {
            System.out.println("las condiciones no son las mejores para caminar");
        }

    }

    public static int mostrarNumeroBuses(int total_participantes) {
        int capacidad_buses = 25;
        int numero_buses = (total_participantes / capacidad_buses);
        if (total_participantes % capacidad_buses != 0) {
            numero_buses++;
        }
        return numero_buses;

    }

    // SEGUIMIENTO
    /**
     * @param pTemperatura temperatura del dia de hoy ingresada por el usuario.
     *                     pTemperatura != null && pTemperatura !="".
     * @param pNombre      el organizador debe ingresar su nombre. pNombre != null
     *                     && pNombre != "".
     * @param args
     */
    public static void ejecutarSeguimiento(Scanner scanner) {
        System.out.println("ingrese la temperatura:");
        int temperatura = scanner.nextInt();
        System.out.println(verificarTemperatura(temperatura));
        System.out.println("ingrese su nombre:");
        scanner.nextLine();
        String nombre_organizador = scanner.nextLine();
        obtenerRegalo(nombre_organizador);
        scanner.close();

    }

    public static String verificarTemperatura(int temperatura) {
        String mensaje = "Disfrute de la caminata";
        if (temperatura < 15) {
            mensaje = "lleve chaqueta para protegerse del frio y de la lluvia";

        } else if (temperatura > 28) {
            mensaje = "lleve el termo del agua, beba para hidratarse ";
        }
        return mensaje;
    }

    /**
     * @param pValidacion se validara si el nombre del organizador empieza por una
     *                    vocal o no, la forma de validacion es un mensaje para
     *                    regalar una entrada gratuita a una conferencia de la
     *                    COP16. pValidacion != null && pValidacion != "".
     */
    public static void obtenerRegalo(String nombre_organizador) {
        char primera_letra = Character.toLowerCase(nombre_organizador.charAt(0));
        if (primera_letra == 'a' || primera_letra == 'e' || primera_letra == 'i' || primera_letra == 'o'
                || primera_letra == 'u') {
            System.out.println(
                    "Comuniquese al numero 1800456789 para obtener una entrada gratuita a una conferencia del COP16.");

        } else {
            System.out.println("muchas gracias");
        }

    }

}
